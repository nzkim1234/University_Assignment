const cp = require('child_process');
cp.execSync('node seqexe.js 11');

// rs = rs.toString();
// console.log(rs);

var i = 10;
while(i--){
    console.log('world');
}
// execSync('node seqexe');