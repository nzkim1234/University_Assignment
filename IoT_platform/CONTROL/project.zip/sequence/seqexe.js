const path = './sequence/'
const cp = require('child_process').spawn;

exports.exe = function exe(cnt, con) {
    // cnt = cnt.split('/')[2];
    // console.log(cnt);
    // console.log(con);
    
    if (con == '11') {
        cp('python3', [path + 'pyp.py']);
    }
    else {
        cp('python3', [path + 'tpy.py']);
    }
}