#include "hw_service.h"
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <string.h>
#include <iostream>
using namespace std;
void child(int pipe_pc[2], int pipe_cp[2]){ 
    close(pipe_pc[1]);
    close(pipe_cp[0]);
    int a;
    int num;
    item_t item;
    int avg;
    int id;
    int i;
    char msg[100];
    read(pipe_pc[0],&a,sizeof(int));
    if(a==1){
        if(start()==0){
            num=getNumStudents();
            write(pipe_cp[1],&num,sizeof(int));
            while(1){
                read(pipe_pc[0],&i,sizeof(int));
                if(i<num){
                    getItem(item); 
                    cout<<"Name: "<<item.student_name<<", ID: "<<item.student_id<<", Grade: "<<item.grade<<endl;
                    write(pipe_cp[1],&item.grade,sizeof(int));
                    deleteItem(item.student_id);
                }
                else{
                    int b=0;
                    write(pipe_cp[1],&b,sizeof(int));
                    break;
                }
            }
        }
    }
    write(pipe_cp[1],&a,sizeof(int));
    read(pipe_pc[0],&a,sizeof(int));
    if(a==0){
        read(pipe_pc[0],&id,sizeof(int));
        read(pipe_pc[0],&avg,sizeof(int));
        checkAnswer(id,avg,msg);
        write(pipe_cp[1],&msg,sizeof(char)*BUF_SIZE);
    }
}

void parent(pid_t c_pid, int pipe_pc[2], int pipe_cp[2]){
    close(pipe_pc[0]);
    close(pipe_cp[1]);
    int a;
    int num;
    int grade;
    int avg;
    int id;
    int sum=0;
    int b;
    char msg[100];
    cout<<"Input 1 to start>> ";
    cin>>a;
    if(a==1){
    write(pipe_pc[1],&a,sizeof(int));
    read(pipe_cp[0],&num,sizeof(int));
    for(int i=0; i<num+1; i++){
        write(pipe_pc[1],&i,sizeof(int));
        read(pipe_cp[0],&grade,sizeof(int));
        sum+=grade;
    }
    read(pipe_cp[0],&b,sizeof(int));
    cout<<"Input 0 to check>> ";
    cin>>a;
    write(pipe_pc[1],&a,sizeof(int));
    avg=sum/num;
    if(a==0){
    cout<<"Input your studentID>> ";
    cin>>id;
    write(pipe_pc[1],&id,sizeof(int));
    write(pipe_pc[1],&avg,sizeof(int));
    read(pipe_cp[0],&msg,sizeof(char)*BUF_SIZE);
    cout<<msg<<endl;
    }
    else{
        cout<<"Wrong Input"<<endl;
    }
    }
    else{
        cout<<"Wrong Input"<<endl;
    }
}
 
int main(){
    int pipe_pc[2], pipe_cp[2];
    pipe(pipe_pc);
    pipe(pipe_cp);
    pid_t pid=fork();
    switch(pid){
        case 0:
            child(pipe_pc,pipe_cp);
            break;
        default:
            parent(pid,pipe_pc,pipe_cp);
            break;
    }
}