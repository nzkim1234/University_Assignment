#include <stdio.h>

#define MAX_LEN 30

unsigned int matching(const char* pattern, FILE *file);