#!/bin/bash

func() {
    for ((i=1; i<=num; i++))
    do
    if ((num%i==0))
    then
    echo $i
    fi
    done
}

func2() {
    for ((i=1; i<=num; i++))
    do
    count=0
    for ((j=2; j<=i; j++))
    do
    if ((i%j==0))
    then
    ((count++))
    fi
    done
    if ((count==1))
    then
    echo $i
    fi
    done
}
while true
do
read num alpha
if [ $num == q -o $num == Q ]
then 
exit
else
case $alpha in
f) func $num;;
p) func2 $num;;
*) echo "Try Again";;
esac
fi
done
